---
layout: post
title: template
---

Once I think template is a kind of sinister design to compete with others because the highlights of product are stolen from outside. No matter how beautiful and exquisite it is (it should be like this), the worst part roots from awkwardly piecing together. The whole style and consistence are broken by sloth.

Later, I found everyone depends on some templates (even those they designs themselves). More time for meaningful work is squeezed out, contributing to higher competitiveness. The upper limit in this period has nothing to do with inherent talent but diligent personality, or say effectiveness.

At the zenith, there should be no template. Template isn't equal to axioms. 