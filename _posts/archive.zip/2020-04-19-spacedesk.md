---
layout: post
title: Spacedesk 创造触屏电脑的简单方式
---
没有触屏电脑，没有买的计划，可以利用spacedesk


利用spacedesk可以实现
* 将平板或者手机或者旧电脑变成拓展屏
* duplicate，用手机或者平板控制电脑，变相实现触屏和遥控器的功能
* 放大投影
* 在手机上体验电脑的系统和软件（啊，我的眼睛）

今天偶然发现觉得非常惊艳好玩。软件官网：<https://spacedesk.net/>。主电脑上下载primary drive。手机上下载sever（google play,appstore都有），另一台电脑的sever可以在Windows store下载。全平台供应。

电脑上下载好之后，记得给防火墙权限，打开就完事了。

手机上打开，首先在setting中设置好分辨率（选手机的还是电脑的）。然后回到主界面，连接primary drive。

电脑上win+p可以调整两个屏幕或者多个屏幕之间的关系。duplicate——触屏效果+遥控器，extend——第二屏幕适合展示。

软件本身的setting等待好好探索，尤其是对多设备的支持。另外在两个屏幕之间的响应略有延迟。

![clipboard](https://i.imgur.com/EWxQZKO.png)
