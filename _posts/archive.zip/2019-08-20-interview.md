---
layout: post
title: part-time job
---

I seems to like the position. But I'm nervous about my employment. May I be employed? It seems my interview is lower than my expectation--no one promise my future work. I think my capacity fits for the position, so does my interest. Please give me the chance!