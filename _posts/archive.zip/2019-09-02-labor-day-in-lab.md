---
layout: post
title: labor day
---

Today is a beautiful day. I just set up preparing the application this fall. Looking through official websites, always I was hit by the English standards because that my inevitable weakness. Gradually, I realized where I should come-- a place accept my English level. As for my academic performance, I'm just shocked again by Will Wang's sharing slides. He is more talented and more industrious than me: working 14 hours per day, short summer holiday for just one week, solving problem a phD left, with good results every week… 

* Asking for availability in Sept.
* Preparing four recommendation letters covering studying capacity, research capacity and ---
* English (that's something I can't force)
* Report to professor at every juncture

I'm unwilling to tell my own stories since they are boring and upsetting. It'd be great that I just describe the life experience of Mr.Z, who has all the stories I want.  