---
layout: post
title: Personal Computer DIY --- choose the softwares
---

You mainly use one laptop, never waste the hardware space installing some boring, ugly or unfriendly-operated softwares. Accept my suggestions and make your own plan.

### Pick some softwares you turly like
Besides those required in daily work, all the kinds of softwares we might use could be categorized into the list:
* Media - audio & video
* News & Books
* Writing & Editing

![liukanshan](http://hbimg.b0.upaiyun.com/43f5114cfbd8d936cddb640b6b1839abc13ef32419555-tbzFDb_fw658)

Every downloading platform also adapt the similar categories, for your easy findind. But what determines your preference is the design, including the function design and the GUI design, isn't it? And even the size, the launch speed? I a big fan of Apple, as well as its simplist style -- let science marry art. When I want to experience a new video player, I would based on the older one's function to search for its alternatives. The website [alternativeto](https://alternativeto.net) will definately offer the best assistance. Remember some useful keyword, like <u>portable, extension</u>, etc.

With the unified style, the laptop is more likely to marked your name.

### Dig the hidding potential of those softwares
If something you can deal with the Chrome, why turn to other software.<br>
It's usual that a new version comes with more funtions, one software could satisfy all the requirements. For instance, Chrome could open htmls, graphs, some types of videos & audios, and pdfs; with some online services or extentions, it's enough to cover all your daily operations. Therefore, the wise company proposes <b>Chrome OS</b>. At the other hand, if you do all the things in a browster, it would be a big challenge for your CPU. 

### Only keep one for the funtion.
And another problem would come up if two softwares have the same function. Now you need to carefully think about your habit and make the choice: delete one or assign seperate part for each one. Otherwise it'll take time for you to determine which one when opening a file. Take it easy. No one enforce you to avoid all the overlapping.

<i>Everyone can find a software, but you can find the software</i>.







